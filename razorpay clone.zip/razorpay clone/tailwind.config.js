/** @type {import('tailwindcss').Config} */
export const content = [ "*" ];
export const theme = {
  extend: {
    animation: {
      'bounce-slow': 'bounce 1.0s infinite',
      'bounce-fast': 'bounce 0.5s infinite',
      'loop-scroll': 'loop-scroll 50s linear infinite'
    },
    keyframes: {
      'loop-scroll': {
        from: { transform: "translateX(0)" },
        to: { teansform: "translateX(-100%" }
      }
    },
    fontFamily: {
      mullish: [ "Mulish", "sans-serif" ],
    },
    colors: {
      deepBlue: "#02042a",
      lightBlue: "#70f6ff;",
      lightBlue300: "#4b94ed",
      lightBlue500: "#0b72e7",
      greenLight: "#61cea6",
      grayText: "#818597",
      lightGray: "#e2e2e2",
      grayBlue: "#344a6c",
      deepBlueHead: "#123644",
      gray2: "#525a76",
      gray1:"#f2f4f8",

      blue200: "#1e75a3",
      black100:"#454545"

    },
  },
};
export const plugins = [];
